import java.util.ArrayList;

public class TestPuzzleJava {
    public static void main(String[] args) {
        // Instantiate the PuzzleJava object
        PuzzleJava generator = new PuzzleJava();

        // Test getTenRolls
        ArrayList<Integer> randomRolls = generator.getTenRolls();
        System.out.println("Random Rolls: " + randomRolls);

        // Test getRandomLetter
        char randomLetter = generator.getRandomLetter();
        System.out.println("Random Letter: " + randomLetter);

        // Test generatePassword
        String randomPassword = generator.generatePassword();
        System.out.println("Random Password: " + randomPassword);

        // Test getNewPasswordSet
        String[] passwordSet = generator.getNewPasswordSet(5);
        System.out.print("Password Set: ");
        for (String password : passwordSet) {
            System.out.println(password);
        }
    }
}
