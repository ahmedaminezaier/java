package com.daikichi.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

    // http://localhost:8080/daikichi
    @RequestMapping("/daikichi")
    public class DaikichiController {

    public String welcome() {
        return "Welcome!";
    }

    // http://localhost:8080/daikichi/today
    @GetMapping("/daikichi/today")
    public String today() {
        return "Today you will find luck in all your endeavors!";
    }

    // http://localhost:8080/daikichi/tomorrow
    @GetMapping("/daikichi/tomorrow")
    public String tomorrow() {
        return "Tomorrow, an opportunity will arise, so be sure to be open to new ideas!";
    }
}
