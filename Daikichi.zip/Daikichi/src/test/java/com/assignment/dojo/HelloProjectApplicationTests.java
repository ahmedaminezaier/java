package com.assignment.dojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
