
public class Gorilla extends Mammal {

    // Gorilla-specific method: throwSomething
    public void throwSomething() {
        this.energy -= 5;
        System.out.println("The gorilla has thrown something! Energy decreased by 5.");
    }

    // Gorilla-specific method: eatBananas
    public void eatBananas() {
        this.energy += 10;
        System.out.println("The gorilla is eating bananas! Energy increased by 10.");
    }

    // Gorilla-specific method: climb
    public void climb() {
        this.energy -= 10;
        System.out.println("The gorilla has climbed a tree! Energy decreased by 10.");
    }
}
