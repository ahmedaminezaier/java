
public class Mammal {
    protected int energy;

    // Constructor to initialize energy
    public Mammal() {
        this.energy = 100; // Default energy level for mammals
    }

    // Method to display and return energy
    public int displayEnergy() {
        System.out.println("Energy level: " + this.energy);
        return this.energy;
    }
}
