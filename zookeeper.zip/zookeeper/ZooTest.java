public class ZooTest {
    public static void main(String[] args) {
        
        // Testing Gorilla class
        Gorilla gorilla = new Gorilla();
        System.out.println("Testing Gorilla:");
        gorilla.throwSomething(); // Decrease energy by 5
        gorilla.throwSomething(); // Decrease energy by 5
        gorilla.throwSomething(); // Decrease energy by 5
        gorilla.eatBananas();     // Increase energy by 10
        gorilla.eatBananas();     // Increase energy by 10
        gorilla.climb();          // Decrease energy by 10
        gorilla.displayEnergy();  // Display energy

        // Testing Bat class
        Bat bat = new Bat();
        System.out.println("\nTesting Bat:");
        bat.attackTown();         // Decrease energy by 100
        bat.attackTown();         // Decrease energy by 100
        bat.attackTown();         // Decrease energy by 100
        bat.eatHumans();          // Increase energy by 25
        bat.eatHumans();          // Increase energy by 25
        bat.fly();                // Decrease energy by 50
        bat.fly();                // Decrease energy by 50
        bat.displayEnergy();      // Display energy
    }
}
