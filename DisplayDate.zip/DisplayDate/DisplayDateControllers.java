package com.DisplayDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class DisplayDateControllers{

    @RequestMapping("/")
    public String dashboard() {
        return "dashboard.jsp";
    }

    @RequestMapping("/date")
    public String showDate(Model model) {
        String formattedDate = new SimpleDateFormat("EEEE, 'the' d 'of' MMMM, yyyy").format(new Date());
        model.addAttribute("currentDate", formattedDate);
        return "date.jsp";
    }

    @RequestMapping("/time")
    public String showTime(Model model) {
        String formattedTime = new SimpleDateFormat("hh:mm a").format(new Date());
        model.addAttribute("currentTime", formattedTime);
        return "time.jsp";
    }
}

public class DisplayDateControllers {

}
