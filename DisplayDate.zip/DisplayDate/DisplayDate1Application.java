package com.DisplayDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisplayDate1Application {

	public static void main(String[] args) {
		SpringApplication.run(DisplayDate1Application.class, args);
	}

}
