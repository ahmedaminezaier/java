public class TestOrder {
    public static void main(String[] args) {
        // Create two orders with default constructor
        Order order1 = new Order();
        Order order2 = new Order();

        // Create three orders using overloaded constructor
        Order order3 = new Order("Alice");
        Order order4 = new Order("Bob");
        Order order5 = new Order("Charlie");

        // Add items to the orders
        Item item1 = new Item("Drip Coffee", 1.50);
        Item item2 = new Item("Cappuccino", 3.50);
        Item item3 = new Item("Latte", 4.00);

        order1.addItem(item1);
        order1.addItem(item2);

        order2.addItem(item2);
        order2.addItem(item3);

        order3.addItem(item1);
        order3.addItem(item3);

        order4.addItem(item1);
        order4.addItem(item2);

        order5.addItem(item2);
        order5.addItem(item3);

        // Set some orders to ready
        order3.setReady(true);
        order5.setReady(true);

        // Test getStatusMessage
        System.out.println(order1.getStatusMessage());
        System.out.println(order3.getStatusMessage());

        // Test getOrderTotal
        System.out.println(order1.getOrderTotal());
        System.out.println(order3.getOrderTotal());

        // Test display method
        order1.display();
        order2.display();
        order3.display();
        order4.display();
        order5.display();
    }
}
