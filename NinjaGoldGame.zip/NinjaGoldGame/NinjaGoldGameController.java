package com.NinjaGoldGame;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

@Controller
public class NinjaGoldGameController {

    // GET method to render the game page
    @GetMapping("/gold")
    public String goldGame(HttpSession session, Model model) {
        // Initialize gold and activities if not present in session
        if (session.getAttribute("gold") == null) {
            session.setAttribute("gold", 0);
        }
        if (session.getAttribute("activities") == null) {
            session.setAttribute("activities", new ArrayList<String>());
        }
        model.addAttribute("gold", session.getAttribute("gold"));
        model.addAttribute("activities", session.getAttribute("activities"));
        return "goldGame.jsp";
    }

    // POST method to process form submissions
    @PostMapping("/process")
    public String processGold(
            @RequestParam("location") String location,
            HttpSession session) {
        
        int gold = (int) session.getAttribute("gold");
        ArrayList<String> activities = (ArrayList<String>) session.getAttribute("activities");

        // Generate gold based on location
        int goldEarnedOrLost = calculateGold(location);
        gold += goldEarnedOrLost;

        // Update session gold
        session.setAttribute("gold", gold);

        // Record activity with timestamp
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String activity = createActivityMessage(location, goldEarnedOrLost, timestamp);
        activities.add(0, activity); // Add latest activity to the top
        session.setAttribute("activities", activities);

        return "redirect:/gold";
    }

    // Helper method to calculate gold
    private int calculateGold(String location) {
        Random random = new Random();
        return switch (location) {
            case "farm" -> random.nextInt(11) + 10;        // 10 - 20
            case "cave" -> random.nextInt(6) + 5;          // 5 - 10
            case "house" -> random.nextInt(4) + 2;         // 2 - 5
            case "quest" -> random.nextInt(101) - 50;      // -50 to 50
            default -> 0;
        };
    }

    // Helper method to create an activity message
    private String createActivityMessage(String location, int goldEarnedOrLost, String timestamp) {
        String outcome = goldEarnedOrLost >= 0 ? "earned" : "lost";
        return String.format("You entered a %s and %s %d gold. (%s)", 
                             location, outcome, Math.abs(goldEarnedOrLost), timestamp);
    }
}

