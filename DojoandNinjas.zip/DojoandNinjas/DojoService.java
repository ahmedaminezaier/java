package com.DojoandNinjas;

public class DojoService {

}
