package com.DojoandNinjas;

public class NinjaController {

}
