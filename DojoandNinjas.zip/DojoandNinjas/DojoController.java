package com.DojoandNinjas;

public class DojoController {

}
