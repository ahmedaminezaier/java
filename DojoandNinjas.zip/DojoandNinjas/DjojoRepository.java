package com.DojoandNinjas;

public interface DjojoRepository {

}
