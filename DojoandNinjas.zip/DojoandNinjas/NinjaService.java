package com.DojoandNinjas;

public class NinjaService {

}
