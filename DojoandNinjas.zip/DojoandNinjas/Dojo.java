package com.DojoandNinjas;

public class Dojo {

}
