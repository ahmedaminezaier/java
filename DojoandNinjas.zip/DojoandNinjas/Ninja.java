package com.DojoandNinjas;

public class Ninja {

}
