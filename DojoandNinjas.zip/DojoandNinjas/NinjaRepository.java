package com.DojoandNinjas;

public interface NinjaRepository {

}
