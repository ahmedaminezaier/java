// Import the necessary java libraries
import java.util.Date;

public class AlfredQuotes {

    // Method 1: Basic greeting (provided as an example)
    public String basicGreeting() {
        return "Hello, lovely to see you. How are you?";
    }

    // Method 2: Guest Greeting
    public String GuestGreeting (String name) {
        return String.format("Hello, %s. Lovely to see you.", name);
    }


    // Method 3: Date Announcement
    public String dateAnnouncement() {
        Date currentDate = new Date();
        return "It is currently " + currentDate.toString();
    }

    // Method 4: Respond Before Alexis
    public String respondBeforeAlexis(String conversation) {
        if (conversation.indexOf("Alexis") > -1) {
            return "Right away, sir. She certainly isn't sophisticated enough for that.";
        } else if (conversation.indexOf("Alfred") > -1) {
            return "At your service. As you wish, naturally.";
        } else {
            return "Right. And with that I shall retire.";
        }
    }

    // Ninja Bonus: Overloaded guestGreeting method with day period
    public String guestGreeting(String name, String dayPeriod) {
        return String.format("Good %s, %s. Lovely to see you.", dayPeriod, name);
    }

    // Sensei Bonus: Overloaded guestGreeting method using Date object to determine day period
    public String guestGreeting(String name) {
        Date currentDate = new Date();
        int hour = currentDate.getHours();
        String dayPeriod;

        if (hour < 12) {
            dayPeriod = "morning";
        } else if (hour < 18) {
            dayPeriod = "afternoon";
        } else {
            dayPeriod = "evening";
        }

        return String.format("Good %s, %s. Lovely to see you.", dayPeriod, name);
    }

    // Sensei Bonus: Create any other method using String manipulation
    public String excitedAnnouncement(String message) {
        return message.toUpperCase() + "!!!";
    }
}
