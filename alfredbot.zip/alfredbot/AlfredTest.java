public class AlfredTest {
    public static void main(String[] args) {
        // Create an instance of AlfredQuotes to access its methods
        AlfredQuotes alfredBot = new AlfredQuotes();
        
        // Test the basic greeting
        String testGreeting = alfredBot.basicGreeting();
        System.out.println(testGreeting);

        // Test guest greeting with a name
        String testGuestGreeting = alfredBot.guestGreeting("Beth Kane");
        System.out.println(testGuestGreeting);

        // Test date announcement
        String testDateAnnouncement = alfredBot.dateAnnouncement();
        System.out.println(testDateAnnouncement);

        // Test respondBeforeAlexis with Alexis in conversation
        String alexisTest = alfredBot.respondBeforeAlexis(
            "Alexis! Play some low-fi beats."
        );
        System.out.println(alexisTest);

        // Test respondBeforeAlexis with Alfred in conversation
        String alfredTest = alfredBot.respondBeforeAlexis(
            "I can't find my yo-yo. Maybe Alfred will know where it is."
        );
        System.out.println(alfredTest);

        // Test respondBeforeAlexis with neither name in conversation
        String notRelevantTest = alfredBot.respondBeforeAlexis(
            "Maybe that's what Batman is about. Not winning. But failing.."
        );
        System.out.println(notRelevantTest);

        // Uncomment each test as you implement the corresponding method
        
        // Test overloaded guestGreeting with day period
        String testOverloadedGuestGreeting = alfredBot.guestGreeting("Beth Kane", "evening");
        System.out.println(testOverloadedGuestGreeting);

        // Test overloaded guestGreeting with Date object for day period
        String testSenseiGuestGreeting = alfredBot.guestGreeting("Beth Kane");
        System.out.println(testSenseiGuestGreeting);

        // Test excited announcement method
        String excitedTest = alfredBot.excitedAnnouncement("Let's go to the Batcave");
        System.out.println(excitedTest);
    }
}

