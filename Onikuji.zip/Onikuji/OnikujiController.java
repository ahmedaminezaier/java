package com.Onikuji;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/omikuji")
public class OnikujiController {

    // Route to render the form
    @GetMapping("")
    public String formPage() {
        return "omikujiForm.jsp";
    }

    // Route to process the form data
    @PostMapping("/process")
    public String processForm(
            @RequestParam("city") String city,
            @RequestParam("person") String person,
            @RequestParam("hobby") String hobby,
            @RequestParam("thing") String thing,
            @RequestParam("nice") String nice,
            HttpSession session) {
        
        // Store form data in session
        session.setAttribute("city", city);
        session.setAttribute("person", person);
        session.setAttribute("hobby", hobby);
        session.setAttribute("thing", thing);
        session.setAttribute("nice", nice);
        
        // Redirect to show the fortune
        return "redirect:/omikuji/show";
    }

    // Route to render the fortune
    @GetMapping("/show")
    public String showFortune(HttpSession session, Model model) {
        // Retrieve session attributes for display in JSP
        model.addAttribute("city", session.getAttribute("city"));
        model.addAttribute("person", session.getAttribute("person"));
        model.addAttribute("hobby", session.getAttribute("hobby"));
        model.addAttribute("thing", session.getAttribute("thing"));
        model.addAttribute("nice", session.getAttribute("nice"));
        return "omikujiShow.jsp";
    }
}
