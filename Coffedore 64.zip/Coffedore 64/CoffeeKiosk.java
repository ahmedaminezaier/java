import java.util.ArrayList;

public class CoffeeKiosk {
    private ArrayList<Item> menu;
    private ArrayList<Order> orders;

    // Constructor initializes menu and orders lists
    public CoffeeKiosk() {
        this.menu = new ArrayList<Item>();
        this.orders = new ArrayList<Order>();
    }

    // Method to add a menu item
    public void addMenuItem(String name, double price) {
        int index = menu.size(); // Index is the size of the current menu
        Item newItem = new Item(name, price, index);
        menu.add(newItem);
    }

    // Method to display the menu
    public void displayMenu() {
        for (Item item : menu) {
            System.out.println(item.getIndex() + " " + item.getName() + " -- $" + item.getPrice());
        }
    }

    // Method to create a new order
    public void newOrder() {
        System.out.println("Please enter customer name for new order:");
        String name = System.console().readLine();
        
        Order order = new Order(name); // Create a new order

        // Show menu
        displayMenu();

        System.out.println("Please enter a menu item index or q to quit:");
        String itemNumber = System.console().readLine();

        // Collect all order items
        while (!itemNumber.equals("q")) {
            try {
                int itemIndex = Integer.parseInt(itemNumber);
                Item itemToAdd = menu.get(itemIndex); // Get the item from the menu
                order.addItem(itemToAdd); // Add item to the order
                System.out.println(itemToAdd.getName() + " added to your order.");
            } catch (Exception e) {
                System.out.println("Invalid item number, try again.");
            }

            System.out.println("Please enter a menu item index or q to quit:");
            itemNumber = System.console().readLine();
        }

        // Add order to orders list and display the order
        orders.add(order);
        order.displayOrder(); // Display the completed order
    }
}