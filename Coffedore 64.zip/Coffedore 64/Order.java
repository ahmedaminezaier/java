import java.util.ArrayList;

public class Order {
    private String customerName;
    private ArrayList<Item> items;

    public Order(String customerName) {
        this.customerName = customerName;
        this.items = new ArrayList<Item>();
    }

    // Method to add an item to the order
    public void addItem(Item item) {
        this.items.add(item);
    }

    // Method to display order details
    public void displayOrder() {
        System.out.println("Order for " + customerName);
        double total = 0;
        for (Item item : items) {
            System.out.println(item.getName() + " -- $" + item.getPrice());
            total += item.getPrice();
        }
        System.out.println("Total: $" + total);
    }
}
