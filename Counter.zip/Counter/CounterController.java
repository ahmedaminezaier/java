package controllers;

public class CounterController {
	import jakarta.servlet.http.HttpSession;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.RequestMapping;

	@Controller
	public class CounterController {
	    
	    @GetMapping("/")
	    public String index(HttpSession session) {
	        // Check if counter exists in session, initialize if not
	        Integer counter = (Integer) session.getAttribute("counter");
	        if (counter == null) {
	            counter = 0;
	        }
	        // Increment the counter
	        session.setAttribute("counter", ++counter);
	        return "index.jsp";
	    }

	    @RequestMapping("/counter")
	    public String counterPage(HttpSession session, Model model) {
	        // Retrieve counter from session
	        Integer counter = (Integer) session.getAttribute("counter");
	        if (counter == null) {
	            counter = 0;
	        }
	        model.addAttribute("counter", counter);
	        return "counter.jsp";
	    }
	}

}
