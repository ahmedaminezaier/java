public class BankAccount {
    // MEMBER VARIABLES
    private double checkingBalance;
    private double savingsBalance;
    private static int accounts = 0;
    private static double totalMoney = 0.0;

    // CONSTRUCTOR
    public BankAccount() {
        checkingBalance = 0.0;
        savingsBalance = 0.0;
        accounts++; // Increment number of accounts whenever a new account is created
    }

    // GETTERS
    public double getCheckingBalance() {
        return checkingBalance;
    }

    public double getSavingsBalance() {
        return savingsBalance;
    }

    public static int getNumberOfAccounts() {
        return accounts;
    }

    public static double getTotalMoney() {
        return totalMoney;
    }

    // METHODS
    public void deposit(double amount, String accountType) {
        if (amount > 0) {
            if (accountType.equals("checking")) {
                checkingBalance += amount;
            } else if (accountType.equals("savings")) {
                savingsBalance += amount;
            }
            totalMoney += amount; // Update totalMoney
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount, String accountType) {
        if (amount > 0) {
            if (accountType.equals("checking") && checkingBalance >= amount) {
                checkingBalance -= amount;
                totalMoney -= amount; // Update totalMoney
            } else if (accountType.equals("savings") && savingsBalance >= amount) {
                savingsBalance -= amount;
                totalMoney -= amount; // Update totalMoney
            } else {
                System.out.println("Insufficient funds.");
            }
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    public void getBalance() {
        System.out.println("Checking Balance: " + checkingBalance);
        System.out.println("Savings Balance: " + savingsBalance);
    }
}
