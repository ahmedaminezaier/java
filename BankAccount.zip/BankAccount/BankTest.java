public class BankTest {
    public static void main(String[] args) {
        // Create 3 bank accounts
        BankAccount account1 = new BankAccount();
        BankAccount account2 = new BankAccount();
        BankAccount account3 = new BankAccount();

        // Deposit Test
        account1.deposit(500, "checking");
        account1.getBalance(); // Should display updated balance

        account2.deposit(1000, "savings");
        account2.getBalance(); // Should display updated balance

        account3.deposit(300, "checking");
        account3.deposit(700, "savings");
        account3.getBalance(); // Should display updated balance

        // Withdrawal Test
        account1.withdraw(200, "checking");
        account1.getBalance(); // Should display updated balance

        account2.withdraw(500, "savings");
        account2.getBalance(); // Should display updated balance

        account3.withdraw(100, "checking");
        account3.withdraw(400, "savings");
        account3.getBalance(); // Should display updated balance

        // Static Test
        System.out.println("Total number of bank accounts: " + BankAccount.getNumberOfAccounts());
        System.out.println("Total money in all accounts: " + BankAccount.getTotalMoney());
    }
}
