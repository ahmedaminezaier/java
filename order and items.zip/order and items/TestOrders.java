public class TestOrders {
    public static void main(String[] args) {
        // Menu items
        Item item1 = new Item("mocha", 3.50);
        Item item2 = new Item("latte", 4.00);
        Item item3 = new Item("drip coffee", 2.50);
        Item item4 = new Item("cappuccino", 4.50);

        // Creating orders
        Order order1 = new Order("Cindhuri");
        Order order2 = new Order("Jimmy");
        Order order3 = new Order("Noah");
        Order order4 = new Order("Sam");

        // Simulate adding items to orders
        order2.addItem(item1);  // Jimmy orders mocha
        order3.addItem(item4);  // Noah orders cappuccino
        order4.addItem(item2);  // Sam orders latte

        // Print the order1 to see what happens
        System.out.println("Order 1: " + order1.name + " Total: $" + order1.total + " Ready: " + order1.ready);
        System.out.println("Predicting total for order 1: " + order1.total);  // Predict total will be $0.0 since no items are added

        // Simulate more orders
        order4.addItem(item2);  // Sam orders another latte
        order1.setReady(true);  // Cindhuri's order is ready
        order2.setReady(true);  // Jimmy's order is ready

        // Print order details after updates
        System.out.println("Order 2: " + order2.name + " Total: $" + order2.total + " Ready: " + order2.ready);
        System.out.println("Order 3: " + order3.name + " Total: $" + order3.total + " Ready: " + order3.ready);
        System.out.println("Order 4: " + order4.name + " Total: $" + order4.total + " Ready: " + order4.ready);
    }
}
