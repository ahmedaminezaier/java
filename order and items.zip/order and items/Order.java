import java.util.ArrayList;

public class Order {
    String name;
    double total;
    boolean ready;
    ArrayList<Item> items;

    public Order(String name) {
        this.name = name;
        this.total = 0.0;
        this.ready = false;
        this.items = new ArrayList<>();
    }

    // Method to add item to the order and update total
    public void addItem(Item item) {
        items.add(item);
        this.total += item.price;
    }

    // Method to update the ready status of the order
    public void setReady(boolean ready) {
        this.ready = ready;
    }
}
