import java.util.HashMap;

public class Hashmatique {
    public static void main(String[] args) {
        // Create a HashMap to store track titles and lyrics
        HashMap<String, String> trackList = new HashMap<>();

        // Add tracks to the HashMap
        trackList.put("Teignmouth Rising", "From the depths of Devon, we rise...");
        trackList.put("Waves of Sound", "Crashing down like waves, the sound envelops...");
        trackList.put("Stars Align", "When the stars align, nothing can stop us...");
        trackList.put("Whispers in the Wind", "Whispers in the wind carry the echoes of our dreams...");

        // Retrieve a specific track by title
        String track = "Stars Align";
        System.out.println("Lyrics for " + track + ": " + trackList.get(track));

        // Print all track titles and their corresponding lyrics
        System.out.println("\nAll Tracks and Lyrics:");
        for (String title : trackList.keySet()) {
            System.out.println("Track: " + title + " | Lyrics: " + trackList.get(title));
        }
    }
}