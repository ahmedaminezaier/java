public class Device {
    protected int battery; // Battery attribute

    // Constructor initializes battery to 100
    public Device() {
        this.battery = 100;
    }

    // Method to display the remaining battery
    public void displayBattery() {
        System.out.println("Battery remaining: " + battery);
    }
}
