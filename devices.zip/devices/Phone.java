public class Phone extends Device {

    // Method to make a call (decreases battery by 5)
    public void makeCall() {
        if (battery >= 5) {
            battery -= 5;
            System.out.println("You make a call.");
        } else {
            System.out.println("Battery too low to make a call.");
        }
        displayBattery();
    }

    // Method to play a game (decreases battery by 20)
    public void playGame() {
        if (battery >= 20) {
            battery -= 20;
            System.out.println("You play a game.");
        } else {
            System.out.println("Battery too low to play a game.");
        }
        displayBattery();
    }

    // Method to charge the phone (increases battery by 50)
    public void charge() {
        battery += 50;
        if (battery > 100) {
            battery = 100; // Ensuring battery doesn't go beyond 100
        }
        System.out.println("You charge the phone.");
        displayBattery();
    }
}
