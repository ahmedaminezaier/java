public class DeviceTest {
    public static void main(String[] args) {
        // Instantiate the Phone object
        Phone myPhone = new Phone();
        
        // Make three phone calls
        myPhone.makeCall();
        myPhone.makeCall();
        myPhone.makeCall();
        
        // Play two games
        myPhone.playGame();
        myPhone.playGame();
        
        // Charge the phone
        myPhone.charge();
    }
}
